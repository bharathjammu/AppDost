# AppDost UI — React + Tailwind (Final Fixed)

This is a fixed, working React + Vite + Tailwind project that includes:
- Dark Mode (toggle)
- Responsive navigation with mobile hamburger menu
- Ready to `npm install` and `npm run dev`

## Setup (local)
1. Ensure Node.js (v18+) is installed.
2. Install packages:

```bash
npm install
```

3. Start the dev server:

```bash
npm run dev
```

Open the URL shown in the terminal (usually http://localhost:5173).

## Build & Preview
```bash
npm run build
npm run preview
```

## Notes
- Tailwind is configured with `darkMode: 'class'`. The theme preference is stored in localStorage.
