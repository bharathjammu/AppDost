import React from 'react'

export default function FeatureCard({ title, desc, icon }) {
  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl card-shadow">
      <div className="text-3xl">{icon}</div>
      <h4 className="mt-4 font-semibold">{title}</h4>
      <p className="mt-2 text-gray-600 dark:text-gray-300 text-sm">{desc}</p>
    </div>
  )
}
