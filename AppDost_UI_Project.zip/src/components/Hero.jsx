import React from 'react'

export default function Hero() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
      <div>
        <h1 className="text-4xl md:text-5xl font-extrabold">Build delightful payments and products — fast.</h1>
        <p className="mt-4 text-gray-600 dark:text-gray-300">A modern toolkit for startups and teams to accept payments, manage users, and ship features reliably.</p>

        <div className="mt-6 flex gap-4">
          <a className="px-6 py-3 bg-primary text-white rounded-md">Start Free</a>
          <a className="px-6 py-3 border rounded-md">Explore Docs</a>
        </div>

        <div className="mt-8 grid grid-cols-3 gap-4 text-sm text-gray-600 dark:text-gray-300">
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg card-shadow">Trusted by 1,200+ teams</div>
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg card-shadow">99.99% uptime</div>
          <div className="bg-white dark:bg-gray-800 p-4 rounded-lg card-shadow">PCI compliant</div>
        </div>
      </div>

      <div className="w-full">
        <div className="h-64 md:h-80 bg-gradient-to-tr from-primary to-accent rounded-2xl shadow-lg flex items-center justify-center text-white text-xl font-semibold">
          Product screenshot
        </div>
      </div>
    </section>
  )
}
