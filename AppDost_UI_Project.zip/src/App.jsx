import React from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import FeatureCard from './components/FeatureCard'
import Footer from './components/Footer'

export default function App() {
  const features = [
    {
      title: 'Seamless Payments',
      desc: 'Fast, secure and developer-friendly payment flows with easy integration.',
      icon: '💳',
    },
    {
      title: 'Developer Tools',
      desc: 'SDKs, APIs and comprehensive docs to ship faster.',
      icon: '🧩',
    },
    {
      title: 'Analytics',
      desc: 'Real-time dashboard to track metrics and conversions.',
      icon: '📊',
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 text-gray-800 dark:text-gray-100">
      <Header />
      <main className="max-w-6xl mx-auto px-6 py-16">
        <Hero />

        <section className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6">
          {features.map((f) => (
            <FeatureCard key={f.title} {...f} />
          ))}
        </section>

        <section className="mt-16 p-8 bg-white dark:bg-gray-900/40 rounded-2xl shadow-md">
          <h3 className="text-2xl font-semibold">Ready to get started?</h3>
          <p className="mt-2 text-gray-600 dark:text-gray-300">Deploy with a single click and integrate in minutes.</p>
          <div className="mt-6 flex gap-4">
            <a href="#" className="px-6 py-3 bg-primary text-white rounded-md shadow hover:opacity-95">Get Started</a>
            <a href="#" className="px-6 py-3 border border-gray-200 dark:border-gray-700 rounded-md">View Docs</a>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
