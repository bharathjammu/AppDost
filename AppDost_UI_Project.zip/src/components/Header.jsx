import React, { useState, useEffect } from 'react'

export default function Header() {
  const [open, setOpen] = useState(false)
  const [isDark, setIsDark] = useState(() => {
    try {
      return localStorage.getItem('theme') === 'dark'
    } catch (e) {
      return false
    }
  })

  useEffect(() => {
    const root = document.documentElement
    if (isDark) {
      root.classList.add('dark')
      localStorage.setItem('theme', 'dark')
    } else {
      root.classList.remove('dark')
      localStorage.setItem('theme', 'light')
    }
  }, [isDark])

  return (
    <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-700">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-primary to-accent flex items-center justify-center text-white font-bold">AD</div>
          <div>
            <div className="font-semibold">AppDost</div>
            <div className="text-xs text-gray-500 dark:text-gray-400">Payments & Tools</div>
          </div>
        </div>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6 text-sm text-gray-700 dark:text-gray-200">
          <a href="#" className="hover:underline">Product</a>
          <a href="#" className="hover:underline">Developers</a>
          <a href="#" className="hover:underline">Pricing</a>
          <a href="#" className="hover:underline">Docs</a>
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsDark(!isDark)}
            aria-label="Toggle dark mode"
            className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            {isDark ? '🌙' : '🌞'}
          </button>

          <div className="hidden md:flex items-center gap-3">
            <button className="text-sm px-4 py-2 rounded-md">Login</button>
            <button className="text-sm px-4 py-2 bg-primary text-white rounded-md">Sign up</button>
          </div>

          {/* Mobile hamburger */}
          <button className="md:hidden p-2" onClick={() => setOpen(!open)} aria-label="Toggle menu">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={open ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'} />
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden px-6 pb-6 space-y-4 border-t dark:border-gray-700">
          <a href="#" className="block">Product</a>
          <a href="#" className="block">Developers</a>
          <a href="#" className="block">Pricing</a>
          <a href="#" className="block">Docs</a>
          <div className="flex items-center gap-2">
            <button className="px-4 py-2 rounded-md">Login</button>
            <button className="px-4 py-2 bg-primary text-white rounded-md">Sign up</button>
          </div>
        </div>
      )}
    </header>
  )
}
