module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: '#0b84ff',
        accent: '#5eead4',
      },
    },
  },
  plugins: [],
}
