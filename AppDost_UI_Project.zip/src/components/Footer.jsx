import React from 'react'

export default function Footer(){
  return (
    <footer className="mt-12 border-t bg-white dark:bg-gray-900 dark:border-gray-700">
      <div className="max-w-6xl mx-auto px-6 py-8 flex flex-col md:flex-row items-center justify-between text-sm text-gray-600 dark:text-gray-300">
        <div>© {new Date().getFullYear()} AppDost UI — built by you</div>
        <div className="flex gap-4 mt-4 md:mt-0">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Contact</a>
        </div>
      </div>
    </footer>
  )
}
